export interface Cocktail {
    id: number;
    name: string;
    ingredients: string;
    image: string;
}