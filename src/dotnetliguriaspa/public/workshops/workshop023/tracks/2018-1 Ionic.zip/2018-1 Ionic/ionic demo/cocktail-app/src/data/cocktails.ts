export default [
    {
        id: 1,
        name: 'Americano',
        ingredients: 'Bitter Campari, Vermouth Rosso, Soda Water',
        image: 'http://www.digicocktails.com/images/cocktails/1.jpg',
    },
    {
        id: 2,
        name: 'Caiporoska',
        ingredients: 'Vidka',
        image: 'http://www.digicocktails.com/images/cocktails/13.jpg',
    },
    {
        id: 3,
        name: 'Daiquiri',
        ingredients: 'Rum Bianco, Succo di Lime, Sciroppo di zucchero di canna',
        image: 'http://www.digicocktails.com/images/cocktails/16.jpg',
    },
    {
        id: 4,
        name: 'Gin Lemon',
        ingredients: 'Gin, Lemon Schweppes o Lemonsoda',
        image: 'http://www.digicocktails.com/images/cocktails/21.jpg',
    },
    {
        id: 5,
        name: 'Long Island Ice Tea',
        ingredients: 'Vodka, Gin, Rum Bianco, Triple Sec, Succo di Limone, Coca Cola',
        image: 'http://www.digicocktails.com/images/cocktails/47.jpg',
    },
    {
        id: 6,
        name: 'Margarita',
        ingredients: 'Tequila, Cointreau, Succo di Limone',
        image: 'http://www.digicocktails.com/images/cocktails/35.jpg',
    },
    {
        id: 7,
        name: 'Mojito',
        ingredients: 'Succo di Lime, Rum Bianco, Soda Water, Menta',
        image: 'http://www.digicocktails.com/images/cocktails/37.jpg',
    },
    {
        id: 8,
        name: 'Negroni',
        ingredients: 'Bitter Campari, Vermouth Rosso, Soda Water, Gin',
        image: 'http://www.digicocktails.com/images/cocktails/2.jpg',
    }
]