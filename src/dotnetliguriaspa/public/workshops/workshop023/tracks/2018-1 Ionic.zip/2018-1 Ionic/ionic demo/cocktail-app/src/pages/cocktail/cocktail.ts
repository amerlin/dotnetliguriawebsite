import { Cocktail } from './../../data/cocktail.interface';
import { Component, OnInit } from '@angular/core';
import { NavParams, AlertController } from 'ionic-angular';

/**
 * Generated class for the CocktailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-cocktail',
  templateUrl: 'cocktail.html',
})
export class CocktailPage implements OnInit {
  
  cocktail: Cocktail;

  ngOnInit(): void {
    this.cocktail = this.navParams.data;
  }

  constructor(private navParams: NavParams, private alertCntr: AlertController) {
  }

  favorite() {
    const alert = this.alertCntr.create({
      title: 'Ti piace proprio?',
      subTitle: 'Te ne berresti almeno 3 di fila?',
      message: 'siii sincero',
      buttons: [
        { 
          text: 'ma si va!',
          handler: () => {
            console.log('OK'); 
          },
        }, 
        {
          text: 'dai no!',
          role: 'cancel',
          handler: () => {
            console.log('Cancelled');
          }
        }
      ],
      
    });

    alert.present();
    
  }


}
