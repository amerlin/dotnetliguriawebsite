import { Cocktail } from './../../data/cocktail.interface';
import { CocktailPage } from './../cocktail/cocktail';
import { Component, OnInit } from '@angular/core';
import { NavController, NavParams, MenuController } from 'ionic-angular';
import cocktails from '../../data/cocktails';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements OnInit {

  ngOnInit(): void {
    this.cocktailsCollection = cocktails;
    console.log(this.cocktailsCollection);
  }

  constructor(public navCtrl: NavController, public navParams: NavParams, private menuCtrl: MenuController) {

  }

  goToCocktail(cocktail: Cocktail) {
    this.navCtrl.push(CocktailPage, cocktail)
  }

  onOpenMenu() {
    this.menuCtrl.open();
  }

  cocktailsCollection: Cocktail[];

}
