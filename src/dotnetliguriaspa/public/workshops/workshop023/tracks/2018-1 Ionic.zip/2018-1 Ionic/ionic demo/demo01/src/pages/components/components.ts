import { Component } from '@angular/core';
import { NavController, ActionSheetController, AlertController, LoadingController, ToastController } from 'ionic-angular';

@Component({
  selector: 'page-components',
  templateUrl: 'components.html'
})
export class ComponentsPage {

  constructor(public navCtrl: NavController, 
    private actionSheetCtrl: ActionSheetController,
    private alertCtrl: AlertController,
    private loadingCtrl: LoadingController,
    private toastCtrl: ToastController) {
  }

  openActionSheet() {
      const actionSheet = this.actionSheetCtrl.create({
        title: 'Try',
        buttons: [
            {
                text: 'Destructive',
                role: 'destructive',
                handler: () => {
                    console.log('Destructive clicked');
                }
            },
            {
                text: 'Archive',
                handler: () => {
                    console.log('Archive clicked');
                }
            },
            {
                text: 'Cancel',
                role: 'cancel',
                handler: () => {
                    console.log('Cancel clicked');
                }
            }
        ]
      });
      actionSheet.present();
  }

  showAlert() {
    const alert = this.alertCtrl.create({
        title: 'New Friends!',
        subTitle: 'Your friend, Obi wan Kenobi, just accepted you friend request!',
        buttons: ['OK']
    });

    alert.present();
  }

  showCheckBox() {
      let alert = this.alertCtrl.create();
      alert.setTitle('Witch planets have you visited?');

      alert.addInput({
          type: 'checkbox',
          label: 'Alderaan',
          value: 'value1',
          checked: false
      });

      alert.addInput({
        type: 'checkbox',
        label: 'Bespin',
        value: 'value2',
        checked: false
      });

      alert.addButton('Cancel');

      alert.present();
  }

  presentLoading() {
    const loader = this.loadingCtrl.create({
        content: "Please wait...",
        duration: 2000
    });

    loader.present();
  }

  showToast() {
    const toast = this.toastCtrl.create({
        message: 'this is a message toast',
        duration: 2000
    });

    toast.present();
  }
}