import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { UsersPage } from '../users/users';
import { ComponentsPage } from '../components/components';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  componentsPage = ComponentsPage;
  constructor(public navCtrl: NavController) {

  }

  onGoUser() {
    this.navCtrl.push(UsersPage, {}, { 
      // direction: 'forward',
      // duration: 2000,
      // easing: 'ease-it'
    });
  }
}
