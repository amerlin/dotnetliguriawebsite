import { Component, OnInit } from "@angular/core";
import { NavParams, NavController } from "ionic-angular";

@Component({
    selector: 'user-page',
    templateUrl: 'user.html'
})

export class UserPage implements OnInit {

    constructor(private navParams: NavParams, private navCtrl: NavController) { }
    name: string;

    ngOnInit(): void {
        this.name = this.navParams.get('userName');
    }

    onGoBack() {
        // this.navCtrl.pop();
        this.navCtrl.popToRoot();
    }
}